package assignment04;

public class Move implements Command {
	int from;
	int to;
	Board board;
	
	public Move (Board brd, int fromIn, int toIn) {
		board = brd;
		from = fromIn;
		to = toIn;
	}

	@Override
	public void execute() {
		TODO 
		Read the name p of the piece at the "from" location
		set the name of the piece at "from" to "  " -- it HAS to be TWO spaces
		set the name of the of the piece at the "to" location to p.
		(use board.getICCF(), etc.)
	}

	public int getFrom() {
		return from;
	}
	public int getTo() {
		return to;
	}
}
