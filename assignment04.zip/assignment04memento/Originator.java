package assignment04memento;
  
import java.util.Stack;

import assignment03B.Board;
import assignment03B.Command;

public class Originator {
	private Stack<Memento> executedStack = new Stack<>();
	private Stack<Command> redoStack = new Stack<>();
	
	public void createMemento(Board board, Command cm) {
		TODO
		make a new MoveMomento for the given board and command
		Push it onto the executedStack
		Clear the redoStack
	}	
	
	public void reset (Board board) {		
		if(!executedStack.isEmpty()) {
			TODO
			Pop the MoveMomento "mmem" from the top of the executedStack
			(you need to use a cast)
			Push the Command stored in "mmem" onto the redoStack 
			Restore the pieces located at "from" and "to".
			(Note "mmem" stores the command "cm" that contains "from" and "to" 
			and the pieces that were on those squares are stored in "mmem")
		}
	}

	public void redo (Board board) {
		if(!redoStack.isEmpty()) {
			TODO
			Pop the Command "cm" from the redoStack.
			make a new MoveMomento for the given board and "cm"
			Push it onto the executedStack
			Execute the command.
			(Do not clear the redoStack in this method)
		}
	}
}
